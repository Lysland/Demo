package com.rootsdk.installapk;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import android.content.Context;
import android.util.Log;

import com.shuame.rootgenius.sdk.RootGenius;
import com.rootsdk.installapk.CommandResult;
import com.rootsdk.installapk.ShellUtils;

public class RootInstallApk {

    private static ShellUtils shellCommand;
    private static CommandResult shellResut;

    private static final String TAG = RootInstallApk.class.getSimpleName();
    private static final String demoSuffix = "_rgsdk/";

    /*unzip armeabi lib from apk*/
    private static ArrayList<String> unzipLib(String srcFile, String targetDir)
    {
        try {

            InputStream is = new FileInputStream(srcFile);
            ZipInputStream zis = new ZipInputStream(is);
            ArrayList<String> libArray = new ArrayList<String>();
            int length = 0;
            byte[] buf = new byte[4096];

            ZipEntry ze = null;
            File aFile = null;
            aFile = new File(targetDir);
            aFile.mkdirs();
            aFile.setExecutable(true, false);
            aFile.setReadable(true, false);

            Log.d(TAG, "unzip " + srcFile);

            while ((ze = zis.getNextEntry()) != null) {

                aFile = new File(targetDir + ze.getName());
                if(ze.getName().indexOf("lib/") == -1) continue;

                if (ze.isDirectory()) {
                    aFile.mkdirs();
                } else {
                    if(aFile.exists()) continue;
                    if(ze.getName().indexOf("armeabi/") == -1) continue;

                    File par = aFile.getParentFile();
                    if (!par.exists()) {
                        par.mkdirs();
                        par.setExecutable(true, false);
                        par.setReadable(true, false);
                    }

                    OutputStream os = new FileOutputStream(aFile);
                    while ((length = zis.read(buf)) > 0) {
                        os.write(buf, 0, length);
                    }
                    os.close();
                }

                aFile.setExecutable(true, false);
                aFile.setReadable(true, false);

                libArray.add(aFile.getCanonicalPath());

                Log.d(TAG, "unzip " + aFile.getCanonicalPath() + " from " + srcFile);
            }
            zis.close();

            return libArray;

        } catch (FileNotFoundException e) {
            Log.w(TAG, e.getMessage());
        } catch (IOException e) {
            Log.w(TAG, e.getMessage());
        }

        return null;
    }

    private static ArrayList<String> extractApkLib(String apkFile, String apkTarget)
    {
        ArrayList<String> libArray = unzipLib(apkFile, apkTarget);

        return libArray;
    }

    private static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        return dir.delete();
    }

    private static String changeFileSElinux(String filePath){
        String script="";
        File file  = new File(filePath);
        String fileName = file.getName();
        String fileParentPath = file.getParent();
        // Check the system if have selinux
        shellCommand = new ShellUtils();
        shellResut = shellCommand.execCommand("getenforce", false, true);
        if (shellResut.result != 0) {
            // system maybe no selinux. "getenforce not found"
            Log.w(TAG, "exec getenforce : " + shellResut.errorMsg);
            return script;
        }else{
            Log.v(TAG,"exec getenforce : "+shellResut.successMsg);
        }
        // get selinux content
        String cmd = "cd "+ fileParentPath +" &  ls -Z * |awk 'NR==1'| awk '{print $4}'";
        shellResut = shellCommand.execCommand(cmd, false, true);
        if (shellResut.result != 0) {
            // system maybe no selinux
            Log.w(TAG, " can't get selinux content : " + shellResut.errorMsg);
            return script;
        }else{
            Log.v(TAG,"the selinux content : "+shellResut.successMsg);
        }
        String SEContent = shellResut.successMsg;
        // set new file's selinux content
        script = "chcon "+SEContent+" "+filePath+"\n";

        return script;
    }

    /*
     * install apk array
     * 安装apk
     * 如果bSystem为真，则将apk安装至system分区，并且将apk中的armeabi版本的库文件拷贝至/system/lib目录
     * 但是，不会覆盖/system/lib目录下的同名库文件
     * 如果bSystem为假，则将apk安装至data分区
     * */
    public static int startInstallApks(Context cntx, String[] apkArray, boolean bSystem) throws Exception {
        if(apkArray == null || apkArray.length == 0) return 0;

        String workDir = cntx.getFilesDir().getAbsolutePath() + "/";
        File libDir = new File(workDir);
        libDir.mkdirs();
        libDir.setExecutable(true);
        libDir.setReadable(true, false);

        String apkLocate = bSystem ? "/system/app/" : "/data/app/";
        String libLocate = "/system/lib/";
        String remount_system = "mount -o rw,remount /system";
        String remount_data = "mount -o rw,remount /data";
        String script = remount_system + "\n" + remount_data + "\n";

        String apkCheckScript = "echo \"<-- apk install result begin -->\"";
        apkCheckScript += "\n";

        for(int i = 0; i < apkArray.length; ++i)
        {
            String apkPath = apkArray[i].trim();
            File apkFile = new File(apkPath);
            if (!apkFile.exists()){
                Log.w(TAG,apkPath+" not found !");
                continue;
            }
            String apkName = apkFile.getName();
            String apkTarget = workDir + apkName.substring(0, apkName.lastIndexOf(".")) + demoSuffix;

            String apkLocateName = apkLocate + apkName;

            //get file SELinux content
            String fileSEContent = changeFileSElinux(apkLocateName);
            //copy file command
            String catCommand = "cat " + apkPath + " > " + apkLocateName;
            script += catCommand;
            script += "\n";
            //change file mode bits command
            String chmodCommand = "chmod 0644 " + apkLocateName;
            script += chmodCommand;
            script += "\n";
            //change file selinux content
            script += fileSEContent;

            //pm install apk command
            String pmCommand = "pm install -r " + apkLocateName;
            script += pmCommand;
            script += "\n";

            //check file exist
            String lsCommand = "ls " + apkLocateName;
            apkCheckScript += lsCommand;
            apkCheckScript += "\n";

            if(bSystem)
            {
                //extract apk's armeabi lib file to dir apkTarget
                ArrayList<String> libArray = extractApkLib(apkPath, apkTarget);
                if(libArray == null || libArray.size() == 0) continue;

                //copy apk's lib file to /system/lib/
                for(int ilib = 0; ilib < libArray.size(); ++ilib)
                {
                    String libName = libArray.get(ilib).trim();
                    File libFile = new File(libName);
                    String libLocateName = libLocate + libFile.getName();
                    File libLocateFile = new File(libLocateName);
                    if(libLocateFile.exists() == false)
                    {
                        //get file SELinux content
                        fileSEContent = changeFileSElinux(libLocateName);
                        //copy file command
                        catCommand = "cat " + libName + " > " + libLocateName;
                        script += catCommand;
                        script += "\n";
                        //change file mode bits command
                        chmodCommand = "chmod 0644 " + libLocateName;
                        script += chmodCommand;
                        script += "\n";
                        //change file selinux content
                        script += fileSEContent;
                        //pm install apk command
                        pmCommand = "pm install -r " + apkLocateName;
                        script += pmCommand;
                        script += "\n";
                    }
                    else
                    {
                        Log.d(TAG, libLocateName + " exist");
                    }

                    //check lib exist
	    			lsCommand = "ls " + libLocateName;
	    			script += lsCommand;
	    			script += "\n";
                }
            }
        }

        apkCheckScript += "echo \"<-- apk install result end -->\"";
        apkCheckScript += "\n";
        script += apkCheckScript;
        Log.i(TAG, script);
    	/*script will run by solution root success*/
        int rootResult = RootGenius.startRootRunScript(cntx, script);

        //delete lib
        if(bSystem)
        {
            for(int i = 0; i < apkArray.length; ++i)
            {
                String apkPath = apkArray[i].trim();

                File apkFile = new File(apkPath);
                String apkName = apkFile.getName();
                String apkTarget = workDir + apkName.substring(0, apkName.lastIndexOf(".")) + demoSuffix;

                Log.d(TAG, "delete dir " + apkTarget);
                File dirTarget = new File(apkTarget);
                deleteDir(dirTarget);
            }
        }

        return rootResult;
    }
}
