package com.rootsdk.installapk;

import com.shuame.rootgenius.sdk.RootGenius;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.io.File;

import com.rootsdk.installapk.RootInstallApk;

import java.io.File;
import java.util.logging.LogRecord;

import com.rootsdk.installapk.ShellUtils;
import com.rootsdk.installapk.CommandResult;

public class MainActivity extends AppCompatActivity implements Runnable{

    private Button mButtonStart;
    private RootInstallApk apkInstall;

    Handler mHandler = new Handler(){
        public void handleMessage(Message msg) {
            Button bt =(Button)findViewById(R.id.startButton);
            switch (msg.what) {
                case 2:
                    String text = "";
                    if (msg.arg1 == RootGenius.RESULT_OK)
                        text += "success";
                    else
                        text += "fail:" + msg.arg1;
                    bt.setText(text);
                case 1:
                    bt.setEnabled(true);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButtonStart = (Button)findViewById(R.id.startButton);
        apkInstall = new RootInstallApk();

        mButtonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button)v;
                b.setText("Runing");
                b.setEnabled(false);

                Thread thread = new Thread(MainActivity.this);
                thread.start();
            }
        });

    }

    public void run()
    {
        // 这里是要批量安装软件的列表.
        String[] apkList = {"/sdcard/01.apk","/sdcard/02.apk","/sdcard/03.apk"};
        try {
            // TODO：正式使用的时候，需要把运行成功的状态保存，以后再运行的时候，根据之前的状态判断是否需要调用root。避免资源浪费
            int ret = apkInstall.startInstallApks(getApplicationContext(),apkList ,true);
            mHandler.obtainMessage(2, ret, 0).sendToTarget();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            mHandler.obtainMessage(1, 0, 0).sendToTarget();
        }
    }
}
